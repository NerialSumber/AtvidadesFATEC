﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace WindowsFormsApp1
{
    public partial class frmexercicio1 : Form
    {
        public frmexercicio1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int qtdBranco = 0;

            for (int i = 0; i < rchtxt1.TextLength; i++)
            {
                if (char.IsWhiteSpace(rchtxt1.Text[i]))
                    qtdBranco += 1;
            }
            if (qtdBranco > 0)
                MessageBox.Show($"O texto Possui {qtdBranco} espaços em branco.");
            else
                MessageBox.Show("O texto não possui espaço em branco.");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            int letraR = 0;

            foreach (char c in rchtxt1.Text.ToUpper())
            {
                if (c is 'R')
                {
                    letraR = letraR + 1;
                }
                
            }
            if (letraR > 0)
                MessageBox.Show($"O texto possui {letraR} caracteres que são letras R.");
            else
                MessageBox.Show("O texto não possui letras R.");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            int Pares = 0, i = 0;

            while (i < rchtxt1.Text.Length)
            
                if
              i.CompareTo(rchtxt1.Text[i + 1]);

        }

        private void rchtxt1_TextChanged(object sender, EventArgs e)
        {
         
        }
    }
    
}

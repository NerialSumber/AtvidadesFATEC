﻿namespace WindowsFormsApp1
{
    partial class frmexercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxt1 = new System.Windows.Forms.RichTextBox();
            this.btnBranco = new System.Windows.Forms.Button();
            this.btnPares = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxt1
            // 
            this.rchtxt1.Location = new System.Drawing.Point(178, 76);
            this.rchtxt1.Name = "rchtxt1";
            this.rchtxt1.Size = new System.Drawing.Size(446, 132);
            this.rchtxt1.TabIndex = 0;
            this.rchtxt1.Text = "";
            this.rchtxt1.TextChanged += new System.EventHandler(this.rchtxt1_TextChanged);
            // 
            // btnBranco
            // 
            this.btnBranco.Location = new System.Drawing.Point(178, 269);
            this.btnBranco.Name = "btnBranco";
            this.btnBranco.Size = new System.Drawing.Size(124, 57);
            this.btnBranco.TabIndex = 1;
            this.btnBranco.Text = "Espaços em branco";
            this.btnBranco.UseVisualStyleBackColor = true;
            this.btnBranco.Click += new System.EventHandler(this.btnBranco_Click);
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(500, 269);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(124, 57);
            this.btnPares.TabIndex = 3;
            this.btnPares.Text = "Pares de Letras";
            this.btnPares.UseVisualStyleBackColor = true;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(337, 269);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(124, 57);
            this.btnR.TabIndex = 4;
            this.btnR.Text = "Letras \"R\"";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.btnR_Click);
            // 
            // frmexercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnBranco);
            this.Controls.Add(this.rchtxt1);
            this.Name = "frmexercicio1";
            this.Text = "frmexercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxt1;
        private System.Windows.Forms.Button btnBranco;
        private System.Windows.Forms.Button btnPares;
        private System.Windows.Forms.Button btnR;
    }
}
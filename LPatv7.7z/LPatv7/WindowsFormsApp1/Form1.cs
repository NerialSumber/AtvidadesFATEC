﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio1>().Count() > 0)
            {
                Application.OpenForms["frmexercicio1"].BringToFront();
            }

            else
            {
                frmexercicio1 obj1 = new frmexercicio1();
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Minimized;
                obj1.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio2>().Count() > 0)
            {
                Application.OpenForms["frmexercicio2"].BringToFront();
            }

            else
            {
                frmexercicio2 obj2 = new frmexercicio2();
                obj2.MdiParent = this;
                obj2.WindowState = FormWindowState.Minimized;
                obj2.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio3>().Count() > 0)
            {
                Application.OpenForms["frmexercicio3"].BringToFront();
            }

            else
            {
                frmexercicio3 obj3 = new frmexercicio3();
                obj3.MdiParent = this;
                obj3.WindowState = FormWindowState.Minimized;
                obj3.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmexercicio4>().Count() > 0)
            {
                Application.OpenForms["frmexercicio4"].BringToFront();
            }

            else
            {
                frmexercicio4 obj4 = new frmexercicio4();
                obj4.MdiParent = this;
                obj4.WindowState = FormWindowState.Minimized;
                obj4.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}

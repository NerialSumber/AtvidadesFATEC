﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    // c# não possui herança multipla
    internal class Horista : Empregado  // herança
    {
        public double SalarioHora { get; set; }

        public double NumeroHora { get; set;}

        public int DiasFalta { get; set; }

        public override double SalarioBruto()  // override indica subscrever
        {
            return SalarioHora * NumeroHora;
        }

        public override int TempoTrabalho()
        {
            TimeSpan span = DateTime.Today.Subtract(DataEntradaempresa);
            return (span.Days - DiasFalta);

        }
    }
}
